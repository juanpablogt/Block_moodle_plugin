<?php
$string['pluginname'] = 'My Companions';
$string['viewcompanions'] = 'View classmates';
$string['sendmessage'] = 'Send message';
$string['selectall'] = 'Select all';
$string['backtocourse'] = 'Back to course';
$string['messagefrom'] = 'Message from {$a}';
$string['messagesent'] = '{$a} message(s) sent successfully.';
$string['nopermissiontosend'] = 'You do not have permission to send messages.';
$string['messageerror'] = 'An error occurred while sending messages.';