<?php
$string['miscompaneros'] = 'Mis compañeros';
$string['pluginname'] = 'Mis compañeros';
$string['miscompaneros:view'] = 'Ver bloque de compañeros';
$string['vercompaneros'] = 'Ver mis compañeros';
$string['companeros'] = 'Compañeros del curso';
$string['sendmessage'] = 'Enviar mensaje';
$string['messagesentsuccess'] = 'El mensaje se ha enviado correctamente.';
$string['messagesentfail'] = 'No se ha podido enviar el mensaje.';
$string['writemessage'] = 'Escriba su mensaje (puede incluir imágenes o HTML):';
$string['returntocourse'] = 'Regresar al curso';