<?php
$string['pluginname'] = 'Mis Compañeros';
$string['viewcompanions'] = 'Ver compañeros de clase';
$string['sendmessage'] = 'Enviar mensaje';
$string['selectall'] = 'Seleccionar todos';
$string['backtocourse'] = 'Volver al curso';
$string['messagefrom'] = 'Mensaje de {$a}';
$string['messagesent'] = 'Se enviaron {$a} mensaje(s) correctamente.';
$string['nopermissiontosend'] = 'No tienes permiso para enviar mensajes.';
$string['messageerror'] = 'Ocurrió un error al enviar los mensajes.';