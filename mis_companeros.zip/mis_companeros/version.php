<?php
$plugin->component = 'block_mis_companeros';
$plugin->version = 2024091000;
$plugin->requires = 2022041900; // Moodle 4.2.1
$plugin->maturity = MATURITY_STABLE;
$plugin->release = '1.0';