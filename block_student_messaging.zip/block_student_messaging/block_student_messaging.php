<?php
require_once('../../config.php');
require_once('message_form.php');
require_once('db/access.php');

class block_student_messaging extends block_base {
    function init() {
        $this->title = get_string('pluginname', 'block_student_messaging');
        $this->version = 2023010100; // Versión del bloque
    }

    function get_content() {
        global $COURSE;

        $courseid = $COURSE->id; // Obtener el ID del curso actual

        // Mostrar el formulario para seleccionar los estudiantes y enviar el mensaje
        $this->content = new stdClass;
        $this->content->text = '';
        $this->content->footer = '';

        // Incluir el formulario
        $this->content->text .= '<form action="" method="post">';
        $this->content->text .= '<input type="hidden" name="courseid" value="' . $courseid . '">';

        // Llamar al formulario de mensaje
        $this->content->text .= message_form($courseid);

        $this->content->text .= '</form>';

        return $this->content;
    }

    function instance_allow_multiple() {
        return false; // No permitir múltiples instancias del bloque
    }

    function has_config() {
        return false; // No permitir configuración del bloque
    }
}