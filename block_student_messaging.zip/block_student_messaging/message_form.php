<?php
function message_form($courseid) {
    global $OUTPUT;

    // Obtener la lista de estudiantes matriculados en el curso
    $enrolled_users = block_student_messaging_get_enrolled_users($courseid);

    // Mostrar la lista de estudiantes
    $html = '<select multiple="multiple" name="users[]">';
    foreach ($enrolled_users as $user) {
        $html .= '<option value="' . $user->id . '">' . $user->firstname . ' ' . $user->lastname . '</option>';
    }
    $html .= '</select>';

    // Campo de texto para ingresar el mensaje
    $html .= '<br>';
    $html .= '<textarea name="message"></textarea>';

    // Botón para enviar el mensaje
    $html .= '<br>';
    $html .= '<input type="submit" value="' . get_string('sendmessage', 'block_student_messaging') . '">';

    return $html;
}