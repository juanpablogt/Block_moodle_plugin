<?php
require_once('../../config.php');
require_once('message_form.php');

$courseid = required_param('courseid', PARAM_INT); // Obtener el ID del curso seleccionado

// Mostrar el formulario para seleccionar los estudiantes y enviar el mensaje
echo '<h2>' . get_string('pluginname', 'block_student_messaging') . '</h2>';
echo message_form($courseid);