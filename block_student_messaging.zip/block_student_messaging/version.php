<?php
$plugin->version   = 2023010100; // Versión del bloque
$plugin->requires  = 2016120500; // Versión de Moodle requerida
$plugin->component = 'block_student_messaging'; // Nombre del bloque
$plugin->release  = '1.0'; // Versión de lanzamiento
$plugin->maturity = MATURITY_STABLE; // Madurez del bloque (estable, beta, alpha)
$plugin->dependencies = array(); // Dependencias del bloque