<?php
function block_student_messaging_get_enrolled_users($courseid) {
    global $DB;
    $sql = "SELECT u.*
             FROM {user} u
             JOIN {user_enrolments} ue ON u.id = ue.userid
             JOIN {enrol} e ON ue.enrolid = e.id
             WHERE e.courseid = ? AND ue.status = 'active' AND u.deleted = 0 AND u.suspended = 0";
    $params = array($courseid);
    $users = $DB->get_records_sql($sql, $params);
    return $users;
}
