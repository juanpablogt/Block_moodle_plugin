<?php
class block_student_messaging extends block_base {

    public function init() {
        $this->title = get_string('pluginname', 'block_student_messaging');
    }

    public function get_content() {
        if ($this->content !== null) {
            return $this->content;
        }

        global $OUTPUT, $USER;

        $this->content = new stdClass;
        
        // Añadir enlace al formulario de mensajes
        $url = new moodle_url('/blocks/student_messaging/view.php', array('courseid' => $this->page->course->id));
        $this->content->text = html_writer::link($url, get_string('sendmessage', 'block_student_messaging'));
        
        return $this->content;
    }
}
